SDB2 to CSV converter


This utility is a python script for converting SDB2 files exported from Shure Wireless Workbench to CSV format. It can be used as a command line utility where the original file is an argument, or simply by dragging an .sdb2 file onto "convert.bat"

PLEASE NOTE: By default, "convert.bat" assumes you have added Python to your path. If you have not, you may need to edit the python directory within it to fit your computer's path. To do so, open the batch file and replace "python" with the full path to the Python installation folder (probably "C:/Python[version]").

Also, be sure to check out Gotham Sound's RF Scan Repository at gothamfaxes.com, where you can view UHF scans from around the world and submit your own in CSV format!


Will Colding
Gotham Sound and Communications
willc@gothamsound.com
11/9/2015