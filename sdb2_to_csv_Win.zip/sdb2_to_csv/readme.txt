SDB2 to CSV converter- Windows executable version


This utility is for converting SDB2 files exported from Shure Wireless Workbench to CSV format. It can be used as a command line utility, or simply by dragging an .sdb2 file onto the .exe.

This version should function regardless of the user's installed python version, or even without python at all. There are hidden libraries in the folder that the .exe accesses. DO NOT DELETE THESE FILES.

'zzz.sdb2' is a sample file included for testing purposes.


Will Colding
Gotham Sound and Communications
willc@gothamsound.com
11/9/2015